#include "asrdev.h"

#pragma GCC diagnostic ignored "-Wunused-variable"
#pragma GCC diagnostic ignored "-Wunused-function"

void ShowBlockData(void* buffer, int size)
{
    int n;
    char sStr[50];
    char sHex[6];
    memset(sStr, 0, sizeof(sStr));
    for (n = 0; n < size; n++) {
        sprintf(sHex, "%02X ", ((UCHAR*)buffer)[n]);
        strcat(sStr, sHex);
        if (n != 0) {
            if ((n + 1) % 16 == 0 || n == size -1) {
                PDEBUG("%s\n", sStr);
                memset(sStr, 0, sizeof(sStr));
            }
        }
    }
}

static int __init asrdev_module_init(void)
{
    int result, n;
    int nDataSize;
    dev_t devno = 0;
    asrdev_devices = NULL;

    PDEBUG("\n\n===== asrdev_module_init =====\n");
    if (asrdev_major) {
        devno = MKDEV(asrdev_major, asrdev_minor);
        result = register_chrdev_region(devno, asrdev_num_devs, DRIVER_NAME);
    } else {
        result = alloc_chrdev_region(&devno, asrdev_minor, asrdev_num_devs, DRIVER_NAME);
        asrdev_major = MAJOR(devno);
    }

    if (result < 0) {
        PDEBUG("Can't get major %d\n", asrdev_major);
        return result;
    }

    charmodule_class = class_create(THIS_MODULE, DEVICE_NAME);
    if (IS_ERR(charmodule_class)) {
        PDEBUG("class_create fail\n");
        return -EFAULT;
    }

    device_create(charmodule_class, NULL, MKDEV(asrdev_major, asrdev_minor), NULL, DEVICE_NAME);

    nDataSize = asrdev_num_devs * sizeof(struct asrdev_data);
    asrdev_devices = kmalloc(nDataSize, GFP_KERNEL);
    if (!asrdev_devices) {
        result = -ENOMEM;
        asrdev_module_clean();
        return result;
    }
    memset(asrdev_devices, 0, nDataSize);

    for (n = 0; n < asrdev_num_devs; n++) {
        mutex_init(&asrdev_devices[n].mutex);
        asrdev_setup_cdev(&asrdev_devices[n], n);
    }    

    return 0;
}

static void __exit asrdev_module_exit(void)
{
    asrdev_module_clean();
    PDEBUG("===== asrdev_module_exit =====\n");
}

static void asrdev_setup_cdev(struct asrdev_data* dev, int index)
{
    int err;
    dev_t devno;

    devno = MKDEV(asrdev_major, asrdev_minor);

    cdev_init(&dev->cdev, &asrdev_fops);
    dev->cdev.owner = THIS_MODULE;
    dev->cdev.ops = &asrdev_fops;
    err = cdev_add(&dev->cdev, devno, 1);
    if (err) {
        PDEBUG("Error %d adding asrdev%d\n", err, index);
    }
}

static void asrdev_module_clean(void)
{
    int n;
    dev_t devno = MKDEV(asrdev_major, asrdev_minor);
    PDEBUG("===== asrdev_module_clean =====\n");
    
    if (asrdev_devices) {
        for (n = 0; n < asrdev_num_devs; n++) {
            cdev_del(&asrdev_devices[n].cdev);
        }
        kfree(asrdev_devices);
    }
    unregister_chrdev_region(devno, asrdev_num_devs);

    device_destroy(charmodule_class, devno);
    class_destroy(charmodule_class);
}

int asrdev_module_open(struct inode* inode, struct file* file)
{
    struct asrdev_data* dev;
    PDEBUG("\n\n===== asrdev_module_open =====\n");
    
    dev = container_of(inode->i_cdev, struct asrdev_data, cdev);
    if (!mutex_trylock(&dev->mutex)) {
        return -EBUSY;
    }

    PDEBUG("===== asrdev_module_open locked =====\n");

    file->private_data = dev;

    if ((file->f_flags & O_ACCMODE) == O_WRONLY) {
    }

    mutex_unlock(&dev->mutex);
    return 0;
}

int asrdev_module_release(struct inode* inode, struct file* file)
{
    PDEBUG("===== asrdev_module_release =====\n");
    return 0;
}

long asrdev_module_ioctl(struct file* file, unsigned int cmd, unsigned long arg)
{
    int err = 0;
    int retval = 0;
    struct asrdev_data* dev;
    ALLOCATE_MEMORY_INFO ami;
    TSmiPara SmiPara;
    KData Data;
    KData* pData = NULL; 
    int kDataSize = 0;

    PDEBUG("===== asrdev_module_ioctl =====\n"); 

    if (_IOC_TYPE(cmd) & _IOC_READ) {  
      #if LINUX_VERSION_500
          err = !access_ok(VERIFY_WRITE, (void __user*)arg, _IOC_SIZE(cmd));
      #else
          err = !access_ok((void __user*)arg, _IOC_SIZE(cmd));
      #endif     
    } else if (_IOC_TYPE(cmd) & _IOC_WRITE) {
      #if LINUX_VERSION_500
          err = !access_ok(VERIFY_READ, (void __user*)arg, _IOC_SIZE(cmd));
      #else
          err = !access_ok((void __user*)arg, _IOC_SIZE(cmd));
      #endif      
    }
    if (err) {
        return -EFAULT;
    }

    
    dev = file->private_data;
    memset(&Data, 0, sizeof(KData));

    switch(cmd) {
        case IOCTL_ALLOCATE_MEMORY:
            PDEBUG("===== IOCTL_ALLOCATE_MEMORY =====\n");
            if(!capable(CAP_SYS_ADMIN)) {
                retval = -EPERM;
                return retval;
            }

            #if LINUX_VERSION_500
                if (!access_ok(VERIFY_READ | VERIFY_WRITE, (void __user*)arg, _IOC_SIZE(cmd))) {
                    retval = -EFAULT;
                    return retval;
                }
            #else
                if (!access_ok((void __user*)arg, _IOC_SIZE(cmd))) {
                    retval = -EFAULT;
                    return retval;
                }
            #endif   

            if (copy_from_user(&ami, (void __user*)arg, sizeof(ALLOCATE_MEMORY_INFO))) {
               retval = -EFAULT;
               return retval;
            }

            if (ami.VirtualAddress != NULL || ami.Size <= 0) {
                retval = -EFAULT;
                return retval;
            }

            ami.VirtualAddress = kzalloc(ami.Size, GFP_KERNEL | __GFP_DMA);
            ami.PhysicalAddress = (void*)virt_to_phys(ami.VirtualAddress);

            if(copy_to_user((void __user*)arg, &ami, sizeof(ALLOCATE_MEMORY_INFO))) {
                retval = -EFAULT;
                return retval;
            }

            retval = ami.Size;
            PDEBUG("===== IOCTL_ALLOCATE_MEMORY OK 0x%X=====\n", ami.PhysicalAddress);
            break;
        case IOCTL_DEALLOCATE_MEMORY:
            PDEBUG("===== IOCTL_DEALLOCATE_MEMORY =====\n");
            if(!capable(CAP_SYS_ADMIN)) {
                retval = -EPERM;
                return retval;
            }
            #if LINUX_VERSION_500
                if (!access_ok(VERIFY_READ | VERIFY_WRITE, (void __user*)arg, _IOC_SIZE(cmd))) {
                    retval = -EFAULT;
                    return retval;
                }
            #else
                if (!access_ok((void __user*)arg, _IOC_SIZE(cmd))) {
                    retval = -EFAULT;
                    return retval;
                }
            #endif 

            if (copy_from_user(&ami, (void __user*)arg, sizeof(ALLOCATE_MEMORY_INFO))) {
               retval = -EFAULT;
               return retval;
            }

            if (ami.VirtualAddress == NULL) {
                retval = -EFAULT;
                return retval;
            }

            kfree(ami.VirtualAddress);

            retval = ami.Size;
            PDEBUG("===== IOCTL_DEALLOCATE_MEMORY OK 0x%X=====\n", ami.PhysicalAddress);
            break;
        case IOCTL_SMI_FUNCTION:
            PDEBUG("===== IOCTL_SMI_FUNCTION =====\n");
            if(!capable(CAP_SYS_ADMIN)) {
                retval = -EPERM;
                return retval;
            }
            #if LINUX_VERSION_500
                if (!access_ok(VERIFY_READ | VERIFY_WRITE, (void __user*)arg, _IOC_SIZE(cmd))) {
                    retval = -EFAULT;
                    return retval;
                }
            #else
                if (!access_ok((void __user*)arg, _IOC_SIZE(cmd))) {
                    retval = -EFAULT;
                    return retval;
                }
            #endif 

            if (copy_from_user(&SmiPara, (void __user*)arg, sizeof(TSmiPara))) {
                retval = -EFAULT;
                return retval;
            }

            retval = SmiFunction(&SmiPara);

            if (copy_to_user((void __user*)arg, &SmiPara, sizeof(TSmiPara))) {
                retval = -EFAULT;
                return retval;
            }

            break;
        case IOCTL_MEM_WRITE:
            PDEBUG("===== IOCTL_MEM_WRITE =====\n");
            if (!capable(CAP_SYS_ADMIN)) {
                retval = -EPERM;
                return retval;
            }
            #if LINUX_VERSION_500
                if (!access_ok(VERIFY_READ | VERIFY_WRITE, (void __user*)arg, _IOC_SIZE(cmd))) {
                    retval = -EFAULT;
                    return retval;
                }    
            #else
                if (!access_ok((void __user*)arg, _IOC_SIZE(cmd))) {
                    retval = -EFAULT;
                    return retval;
                }    
            #endif    

            if (copy_from_user(&Data, (void __user*)arg, sizeof(KData))) {
                retval = -EFAULT;
                return retval;
            }

            kDataSize = sizeof(KData) + Data.ami.Size - 1;
            pData = kmalloc(kDataSize, GFP_KERNEL);
            if (pData == NULL) {
                retval = -EFAULT;
                kfree(pData);
                return retval;
            }

            if (copy_from_user(pData, (void __user*)arg, kDataSize)) {
                retval = -EFAULT;
                kfree(pData);
                return retval;
            }

            if (!pData->ami.PhysicalAddress) {
                retval = -EFAULT;
                kfree(pData);
                return retval;
            }
            ShowBlockData(pData, kDataSize);

#ifdef __LP64___
            PDEBUG("PHY_ADDR %X\n", pData->ami.PhysicalAddress);
            pData->ami.VirtualAddress = phys_to_virt((UINT64)pData->ami.PhysicalAddress);
#else            
            PDEBUG("PHY_ADDR %X\n", pData->ami.PhysicalAddress);
            pData->ami.VirtualAddress = phys_to_virt(pData->ami.PhysicalAddress);
#endif

            if (!mutex_trylock(&dev->mutex)) {
                kfree(pData);
                return -EBUSY;
            }
            memcpy((void*)pData->ami.VirtualAddress, (void*)&pData->Data[0], pData->ami.Size);
            ShowBlockData(pData->ami.VirtualAddress, pData->ami.Size);
            mutex_unlock(&dev->mutex);
            
            retval = pData->ami.Size;
            kfree(pData);
            break;
        case IOCTL_MEM_READ:
            PDEBUG("===== IOCTL_MEM_READ =====\n");           
            
            if (!capable(CAP_SYS_ADMIN)) {
                retval = -EPERM;
                return retval;
            }
            #if LINUX_VERSION_500
                if (!access_ok(VERIFY_READ | VERIFY_WRITE, (void __user*)arg, _IOC_SIZE(cmd))) {
                    retval = -EFAULT;
                    return retval;
                }  
            #else
                if (!access_ok((void __user*)arg, _IOC_SIZE(cmd))) {
                    retval = -EFAULT;
                    return retval;
                }   
            #endif  
            
            if (copy_from_user(&Data, (void __user*)arg, sizeof(KData))) {
                retval = -EFAULT;
                return retval;
            }

            kDataSize = sizeof(KData) + Data.ami.Size - 1;
            pData = kmalloc(kDataSize, GFP_KERNEL);
            if (pData == NULL) {
                retval = -EFAULT;
                kfree(pData);
                return retval;
            }

            if (copy_from_user(pData, (void __user*)arg, kDataSize)) {
                retval = -EFAULT;
                kfree(pData);
                return retval;
            }

            if (!pData->ami.PhysicalAddress) {
                retval = -EFAULT;
                kfree(pData);
                return retval;
            }
#ifdef __LP64__
            pData->ami.VirtualAddress = phys_to_virt((UINT64)pData->ami.PhysicalAddress);
#else
            pData->ami.VirtualAddress = phys_to_virt(pData->ami.PhysicalAddress);
#endif

            if (!mutex_trylock(&dev->mutex)) {
                kfree(pData);
                return -EBUSY;
            }
            memcpy((void*)pData->Data, (void*)pData->ami.VirtualAddress, pData->ami.Size);
            mutex_unlock(&dev->mutex);

            if (copy_to_user((void __user*)arg, pData, kDataSize)) {
                retval = -EFAULT;
                kfree(pData);
                return retval;
            }

            ShowBlockData(pData, kDataSize);

            retval = pData->ami.Size;
            kfree(pData);
            
            break;
            
        default:
            break;
    }

    return retval;
}

static int SmiFunction(PSmiPara volatile SysBuf)
{
    static UINT32 ddEAX;
    static UINT32 ddEBX;
    static UINT32 ddECX;
    static UINT32 ddEDX;
    static UINT32 ddESI;
    static UINT32 ddEDI;

    ddEAX = SysBuf->ddEAX;
    ddEBX = SysBuf->ddEBX;
    ddECX = SysBuf->ddECX;
    ddEDX = SysBuf->ddEDX;
    ddESI = SysBuf->ddESI;
    ddEDI = SysBuf->ddEDI;

    
    PDEBUG("===== SmiFunction Input =====\n");
    PDEBUG("EAX = 0x%08X\n", ddEAX);
    PDEBUG("EBX = 0x%08X\n", ddEBX);
    PDEBUG("ECX = 0x%08X\n", ddECX);
    PDEBUG("EDX = 0x%08X\n", ddEDX);
    PDEBUG("ESI = 0x%08X\n", ddESI);
    PDEBUG("EDI = 0x%08X\n", ddEDI);

    
#ifdef __LP64__
    __asm__ __volatile__  (
            "pushq %%rax\n"
            "pushq %%rbx\n"
            "pushq %%rcx\n"
            "pushq %%rdx\n"
            "pushq %%rsi\n"
            "pushq %%rdi\n"

            "mov %6, %%eax\n"
            "mov %7, %%ebx\n"
            "mov %8, %%ecx\n"
            "mov %9, %%edx\n"
            "mov %10, %%esi\n"
            "mov %11, %%edi\n"
            "out %%al, (%%dx)\n"
            "mov %%eax, %0\n"
            "mov %%ebx, %1\n"
            "mov %%ecx, %2\n"
            "mov %%edx, %3\n"
            "mov %%esi, %4\n"
            "mov %%edi, %5\n"

            "popq %%rdi\n"
            "popq %%rsi\n"
            "popq %%rdx\n"
            "popq %%rcx\n"
            "popq %%rbx\n"
            "popq %%rax"
           : "=m"(ddEAX),
             "=m"(ddEBX),
             "=m"(ddECX),
             "=m"(ddEDX),
             "=m"(ddESI),
             "=m"(ddEDI)
           : "m"(ddEAX),
             "m"(ddEBX),
             "m"(ddECX),
             "m"(ddEDX),
             "m"(ddESI),
             "m"(ddEDI)
    );
#else

    __asm__ __volatile__  (
            "push %%eax\n"
            "push %%ebx\n"
            "push %%ecx\n"
            "push %%edx\n"
            "push %%esi\n"
            "push %%edi\n"

            "mov %6, %%eax\n"
            "mov %7, %%ebx\n"
            "mov %8, %%ecx\n"
            "mov %9, %%edx\n"
            "mov %10, %%esi\n"
            "mov %11, %%edi\n"
            "out %%al, (%%dx)\n"
            "mov %%eax, %0\n"
            "mov %%ebx, %1\n"
            "mov %%ecx, %2\n"
            "mov %%edx, %3\n"
            "mov %%esi, %4\n"
            "mov %%edi, %5\n"

            "pop %%edi\n"
            "pop %%esi\n"
            "pop %%edx\n"
            "pop %%ecx\n"
            "pop %%ebx\n"
            "pop %%eax"
           : "=m"(ddEAX),
             "=m"(ddEBX),
             "=m"(ddECX),
             "=m"(ddEDX),
             "=m"(ddESI),
             "=m"(ddEDI)
           : "m"(ddEAX),
             "m"(ddEBX),
             "m"(ddECX),
             "m"(ddEDX),
             "m"(ddESI),
             "m"(ddEDI)
          : "%eax", "%ebx", "%ecx", "%edx", "%esi", "%edi"
    );
#endif


    SysBuf->ddEAX = ddEAX;
    SysBuf->ddEBX = ddEBX;
    SysBuf->ddECX = ddECX;
    SysBuf->ddEDX = ddEDX;
    SysBuf->ddESI = ddESI;
    SysBuf->ddEDI = ddEDI;

    PDEBUG("===== SmiFunction Output =====\n");
    PDEBUG("SysBuf->ddEAX = 0x%08X\n", SysBuf->ddEAX);
    PDEBUG("SysBuf->ddEBX = 0x%08X\n", SysBuf->ddEBX);
    PDEBUG("SysBuf->ddECX = 0x%08X\n", SysBuf->ddECX);
    PDEBUG("SysBuf->ddEDX = 0x%08X\n", SysBuf->ddEDX);
    PDEBUG("SysBuf->ddESI = 0x%08X\n", SysBuf->ddESI);
    PDEBUG("SysBuf->ddEDI = 0x%08X\n", SysBuf->ddEDI);
    return 0;
}

