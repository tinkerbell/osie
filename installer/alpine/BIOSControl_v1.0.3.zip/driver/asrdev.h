#ifndef __ASRDEV_H__
#define __ASRDEV_H__

#include <linux/init.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/efi.h>
#include <asm/uaccess.h>

#include "asrdev_ioctl.h"
#include "ver.h"

#undef PDEBUG
#ifdef USE_DEBUG
    #define PDEBUG(fmt, args...) printk(KERN_DEBUG "ASRDEV: " fmt, ## args)
#else
    #define PDEBUG(fmt, args...)
#endif // ASRDEV_DEBUG

#define DRIVER_NAME             "asrdev"
#define DEVICE_NAME             "asrdev"
#define VER                     "V1"

static int asrdev_major         = 0;
static int asrdev_minor         = 0;
static int asrdev_num_devs      = 1;
static struct class* charmodule_class;


module_param(asrdev_major, int, S_IRUGO);
module_param(asrdev_minor, int, S_IRUGO);
module_param(asrdev_num_devs, int, S_IRUGO);

struct asrdev_data
{
    struct cdev cdev;
    struct mutex mutex;
};
static struct asrdev_data* asrdev_devices;

static int __init asrdev_module_init(void);
static void __exit asrdev_module_exit(void);
module_init(asrdev_module_init);
module_exit(asrdev_module_exit);

static void asrdev_setup_cdev(struct asrdev_data* dev, int index);
static void asrdev_module_clean(void);

int asrdev_module_open(struct inode* inode, struct file* file);
int asrdev_module_release(struct inode* inode, struct file* file);
long asrdev_module_ioctl(struct file* file, unsigned int cmd, unsigned long arg);

static int SmiFunction(PSmiPara volatile SysBuf);

static struct file_operations asrdev_fops = 
{
    .owner = THIS_MODULE,
    .unlocked_ioctl = asrdev_module_ioctl,
    .compat_ioctl = asrdev_module_ioctl,
    .open = asrdev_module_open,
    .release = asrdev_module_release
};

//MODULE_LICENSE("Proprietary");
MODULE_LICENSE("Dual BSD/GPL");
MODULE_AUTHOR("www.asrock.com.tw");
MODULE_VERSION("1.0.0");
MODULE_DESCRIPTION("ASRock system device driver");

#endif // __ASRDEV_H__
