#ifndef __ASRDEV_IOCTL_H__
#define __ASRDEV_IOCTL_H__

#ifdef __KERNEL__
#include <linux/ioctl.h>
#else
#include <sys/ioctl.h>
#endif // __KERNEL__

#include "define.h"

#pragma pack(push, 1)

typedef struct
{
    UINT32 Size;
    //PVOID PhysicalAddress;
    //PVOID VirtualAddress;
    UINT64 PhysicalAddress;
    UINT64 VirtualAddress;
} ALLOCATE_MEMORY_INFO, *PALLOCATE_MEMORY_INFO;

typedef struct
{
    UINT32 ddEAX;
    UINT32 ddEBX;
    UINT32 ddECX;
    UINT32 ddEDX;
    UINT32 ddESI;
    UINT32 ddEDI;
} TSmiPara, *PSmiPara;

typedef struct
{
    UINT32 Data1;
    UINT16 Data2;
    UINT16 Data3;
    UINT8  Data4[8];
} EFI_GUID;

typedef struct _VARIABLE_BLOCK {
    EFI_GUID VendorGuid;
    UINT32 VariableName;
    UINT32 Attributes;
    UINT32 DataSize;
    UINT32 Data;
} VARIABLE_BLOCK,*PVARIABLE_BLOCK;

typedef struct _GET_NEXT_VARIABLE_BLOCK {
    EFI_GUID VendorGuid;
    UINT32 VariableName;
    UINT32 VariableNameSize;
} GET_NEXT_VARIABLE_BLOCK, *PGET_NEXT_VARIABLE_BLOCK;

typedef struct _EXPORT_HIIDB_BLOCK {
    UINT32 DataSize;
    UINT32 Data;
} EXPORT_HIIDB_BLOCK;

typedef struct _REG_BLOCK {
    UINT32 EAX;
    UINT32 EBX;
    UINT32 ECX;
    UINT32 EDX;
    UINT32 ESI;
    UINT32 EDI;
    UINT32 EFLAGS;
    UINT16 ES;
    UINT16 CS;
    UINT16 SS;
    UINT16 DS;
    UINT16 FS;
    UINT16 GS;
    UINT32 EBP;
    UINT32 ESP;
} REG_BLOCK;

typedef struct
{
    ALLOCATE_MEMORY_INFO ami;
    UCHAR Data[1];
} KData, *PKData;

#pragma pack(pop)

#define IOC_MAGIC                   'K'

#define IOCTL_ALLOCATE_MEMORY       _IOWR(IOC_MAGIC, 1, ALLOCATE_MEMORY_INFO)
#define IOCTL_DEALLOCATE_MEMORY     _IOWR(IOC_MAGIC, 2, ALLOCATE_MEMORY_INFO)
#define IOCTL_SMI_FUNCTION          _IOWR(IOC_MAGIC, 3, TSmiPara)
#define IOCTL_MEM_WRITE             _IOWR(IOC_MAGIC, 4, KData)
#define IOCTL_MEM_READ              _IOWR(IOC_MAGIC, 5, KData)


#endif // __ASRDEV_IOCTL_H__
