#!/bin/bash

sudo cp asrdev.ko /lib/modules/`uname -r`/kernel
sudo depmod
sudo modprobe -r asrdev
sudo modprobe asrdev
echo "asrdev" > asrdev.conf
sudo cp asrdev.conf /etc/modules-load.d/asrdev.conf
