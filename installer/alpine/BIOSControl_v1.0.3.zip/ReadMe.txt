1.  Build environment
	ubuntu
       		sudo apt-get update
       		sudo apt-get install build-essential
	RedHat or CentOS
		yum update
	RedHat 8.0
		yum update
		sudo dnf install elfutils-libelf-devel

2. Enter drivers folder
	sudo chmod 777 Install.sh
     	sudo make
     	sudo ./Install

3. Enter BIOSContorl folder to execute program
     Usage:
        Dump the Data:
          BIOSContorl /g "Output Filename"
        Input the Data By File:
          BIOSContorl /s "Input Filename"
        Input File example:
          [{"Question Id" : 212,"PkgListGuid" : "{ABBCE13D-E25A-4D9F-A1F9-2F7710786892}","Title" : "Fast Boot","Value" : 2}]
        Input the Data By parameters:
          BIOSContorl T="Title" V="Value"
        Input parameters example:
          BIOSContorl T="Fast Boot" V=2

     